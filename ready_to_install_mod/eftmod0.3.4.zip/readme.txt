A mod that adds an [eft] bbcode.

The bbcode displays a battleclinic-like layout when provided with an EFT output.

Based of https://forums.eveonline.com/default.aspx?g=posts&t=49402 for PHPBB, simply modified for SMF.

The theme has been designed for my forum, feel free to edit the design in the attached css file.

Feel free to comment on the "official" thread for request/support
https://forums.eveonline.com/default.aspx?g=posts&t=352566

-Soressean Goldenheart

Ship DNA mod by Erwin Krym'L included,
Database Update (Citadel) included by Soressean Goldenheart,

If you have a custom theme you will need to copy a few files across manually.
These files are as follows:
fitting.css -> theme_directory/css
fitting.js -> theme_directory/scripts
eft.gif -> theme_directory/images/bbc